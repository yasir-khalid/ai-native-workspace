from pathlib import Path
import subprocess
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
base=Path(__file__).resolve().parent
main=(base/'ARCHITECTURE.md').read_text()
main=main.replace('# PodOS: AI-Native Research Workspace for Multi-Manager Funds\n','',1)
# Definition of done is already captured in the main document and Agent Handoff;
# suppress the repeated final line in the paginated human-readable rendering.
main=main.split('\n---\n\n**Definition of done:**')[0]
(base/'_docx_input.md').write_text(main)
p=base/'PodOS_Architecture_Design.docx'
subprocess.run(['pandoc','_docx_input.md','--from=gfm','--to=docx','--toc','--toc-depth=2',
                '-M','title=PodOS: AI-Native Research Workspace',
                '-M','subtitle=Architecture for Multi-Manager Investment Funds',
                '-o',str(p)],cwd=base,check=True)
doc=Document(p)
sec=doc.sections[0]
sec.top_margin=Inches(.78);sec.bottom_margin=Inches(.75)
sec.left_margin=Inches(.78);sec.right_margin=Inches(.78)
sec.header_distance=Inches(.36);sec.footer_distance=Inches(.38)
normal=doc.styles['Normal'];normal.font.name='Liberation Sans';normal.font.size=Pt(9);normal.font.color.rgb=RGBColor(39,54,71)
normal.paragraph_format.space_after=Pt(4.9);normal.paragraph_format.line_spacing=1.12
for sty,size,clr,prev,after in [('Title',24,(22,49,84),0,12),('Subtitle',11,(90,113,139),0,9),('Heading 1',15,(23,65,111),14,7),('Heading 2',12,(32,86,141),11,5),('Heading 3',10.2,(32,86,141),8,3)]:
 if sty in doc.styles:
  s=doc.styles[sty];s.font.name='Liberation Sans';s.font.size=Pt(size);s.font.bold=sty!='Subtitle';s.font.color.rgb=RGBColor(*clr)
  s.paragraph_format.space_before=Pt(prev);s.paragraph_format.space_after=Pt(after);s.paragraph_format.keep_with_next=True
for t in doc.tables:
 t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=True
 for i,row in enumerate(t.rows):
  for cell in row.cells:
   cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
   if i==0:
    tcpr=cell._tc.get_or_add_tcPr();shd=OxmlElement('w:shd');shd.set(qn('w:fill'),'E8F0F8');tcpr.append(shd)
   for para in cell.paragraphs:
    para.paragraph_format.space_after=Pt(1.5)
    for run in para.runs:
     run.font.size=Pt(7.6)
     if i==0:run.font.bold=True;run.font.color.rgb=RGBColor(22,64,109)
for para in doc.paragraphs:
 if para.style.name.startswith('Source Code') or para.style.name=='Verbatim Char':
  para.paragraph_format.space_after=Pt(5)
  for run in para.runs:run.font.name='DejaVu Sans Mono';run.font.size=Pt(7.3)
# Images 0: topology, 1: sync, 2: async. Keep diagrams within a page's text area.
for i,shape in enumerate(doc.inline_shapes):
 if i==0:shape.height=Inches(5.1);shape.width=Inches(4.07)
 else:shape.width=Inches(6.35);shape.height=Inches(2.22)
h=sec.header.paragraphs[0];h.text='PodOS  /  Multi-Manager AI Workspace    |    Technical Architecture'
h.style=doc.styles['Normal'];h.alignment=WD_ALIGN_PARAGRAPH.RIGHT
for r in h.runs:r.font.size=Pt(7);r.font.color.rgb=RGBColor(106,124,144)
f=sec.footer.paragraphs[0];f.alignment=WD_ALIGN_PARAGRAPH.RIGHT
r=f.add_run('Proposed design  |  10 Oct 2026  |  ');r.font.size=Pt(7);r.font.color.rgb=RGBColor(106,124,144)
field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');f._p.append(field)
doc.core_properties.title='PodOS: AI-Native Research Workspace for Multi-Manager Funds'
doc.core_properties.subject='Implementation-ready architecture and technical design'
doc.core_properties.keywords='AI workspace, multi-manager fund, Google ADK, pod isolation, A2A, agent registry'
doc.core_properties.author=''
doc.save(p)
(base/'_docx_input.md').unlink()
print('Saved',p,'paragraphs',len(doc.paragraphs),'tables',len(doc.tables),'inline images',len(doc.inline_shapes))
