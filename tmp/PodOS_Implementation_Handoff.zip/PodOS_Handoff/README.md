# PodOS architecture handoff package

**Main document:** [`ARCHITECTURE.md`](ARCHITECTURE.md)  
**Implementation instructions:** [`AGENT_HANDOFF.md`](AGENT_HANDOFF.md)  
**Contract schemas:** [`contracts/`](contracts/)  
**Database starter:** [`sql/001_initial.sql`](sql/001_initial.sql)  
**Architecture diagrams:** [`diagrams/`](diagrams/)

Use the Markdown files as the authoritative, agent-readable specification. The Word document is a human-readable rendering of the same design.

The design assumes a two-pod proof of concept with centrally managed reusable agents and strict pod research isolation. The 15,000-user scenario is a scale aspiration, not a measured capacity claim.

The schemas, SQL and diagrams are **starter implementation artifacts**; validate and harden them in the target environment. Confirm dependency licences at pin time and avoid restrictive `CopilotKit/showcase` source files or `novu/enterprise` code.
